# ORVYREN — audit packet (rseth, run 01M526YS)

Testnet only (Base Sepolia, chainId 84532). No real funds were involved.
This packet is the auditable record of the ORVYREN demonstration run
(`run_id = 01M526YS3FMDNS6Z9EJYJPPG1E`), assembled offline by `scripts/build_audit_packet.py`.
It carries **three journals** (execution / reasoning / knowledge), sealed by a
manifest and a LINK/SEAL junction (B6 §1.4), and a **frozen copy of the
third-party verifier** (T10).

## How to verify (offline, no network, no repository needed)

```bash
unzip audit_packet_rseth_20261016-2340_01M526YS.zip && cd audit_packet_rseth_20261016-2340_01M526YS
# 1) file integrity: every file against HASHES.txt (and the bundle digest)
sha256sum -c HASHES.txt        # the verifier redoes this check (A3) if coreutils is absent
# 2) full offline verification — expected: VERDICT: OFFLINE_PASS
python verify/orvyren_verify.py .
# 3) mutation self-test — expected: 6/6 mutations detected
python verify/orvyren_verify.py . --mutate-test
```

With network (optional, separate verdict): `python verify/orvyren_verify.py . --rpc https://sepolia.base.org`
re-reads every recorded transaction from the chain and re-matches it to its intent.

## What this audit packet proves

**What this audit packet proves.** (1) **Integrity** — no byte of the dossier or its journals has changed since sealing: any alteration breaks a hash chain or the dossier self-hash (INV-INTEGRITY). (2) **Recomputability** — every determinant computation (policy verdicts, dossier re-rendering, graph snapshot, intent↔receipt matching) is recomputed **offline** by a third party from the supplied pieces alone: same inputs, same versions, same outputs. (3) **Intent↔execution correspondence** — each recorded transaction is tied to an intent and a policy verdict and cross-checked against the public receipt (status, block, logs). (4) **Bounded mandate** — what the agent *could* do is a public, dated on-chain fact; the worst case is a finite, readable number. (5) **Point-in-time admissibility (INV-PIT)** — every fact carries event and retrieval timestamps; data inadmissible at decision time is excluded from the decision path. (6) **Refusals preserved** — policy denials, rejections, quarantines and abstentions are journaled and counted. (7) **Channel independence (INV-DEPENDENCE)** — two channels from the same archive never count as two confirmations. (8) **Accountability** — every step is attributed to a versioned component with its inputs and outputs.

## What this audit packet does not prove

**What this audit packet does not prove.** (1) The **truthfulness** of external sources — an oracle can be wrong while every hash is valid. (2) The **soundness** of hypotheses or the quality of decisions. (3) Any **financial performance** (returns, avoided loss, superiority over a baseline) — none is claimed. (4) **Completeness** — the packet covers signer actions and journaled steps; anything not journaled is not in it. (5) **LLM call text is not replayed** (inference nondeterminism); it is **covered by the journal** (prompts and responses archived and hashed, validators replayed). (6) Absence of **bugs** in upstream components. (7) **Legal or regulatory compliance** in any jurisdiction. (8) A **sealed digest** (if anchored) proves the integrity and dating of the anchored dossier, **not its truthfulness**.

## Inventory

- `audit.jsonl`
- `baseline_report.json`
- `decision_usdc-2023-03.json`
- `dossier_usdc-2023-03.html`
- `dossier_usdc-2023-03.md`
- `fixtures/corpus_usdc_observations.csv`
- `fixtures/episode_rseth_2026-04.json`
- `fixtures/episode_steth_2022-06.json`
- `fixtures/episode_usdc_2023-03.json`
- `fixtures/graphs/rseth_2026-04.json`
- `fixtures/graphs/steth_2022-06.json`
- `fixtures/graphs/usdc_2023-03.json`
- `graph/graph_delta.jsonl`
- `graph/graph_snapshot.json`
- `graph/provenance.json`
- `manifest.json`
- `policy/intent_registry.json`
- `policy/policy.demo.json`
- `policy/policy.effective.json`
- `policy/signatures.jsonl`
- `policy_execution_demo.json`
- `quality_report.json`
- `receipts/0x17e94df4255b0f09132c4952ab90a199ed678df383c7e90db356c2590274ff05.json`
- `receipts/0x2d7eae5f5ab0917e629c0f8194b884ae4e968ecb21dfd2ce1f3494297060bf96.json`
- `receipts/0x34819b1da9f76417c3f480b6cd91c0ba41818092cb12690e0f5c8af363525641.json`
- `receipts/0x43bd6bf606afb2a02772ec20321428837b0d903c61853eed73e0bf7a53da0247.json`
- `receipts/0x508b13cf13b55fc17b44e2eb12bc7345d078e5284c62271a7c1b0098b81fefc9.json`
- `receipts/0x7548461ed0e49cf3b21a43377ffcf20b9de7e415fa746b252edebe212ba1b4ab.json`
- `receipts/0x82827c701e03852ae0e2176be1984ddfbc2420228cd9cd8db73986e2f6734f53.json`
- `receipts/0x8e6beda64ca8a9da6e839dd406cf7262eaeb986b602a2ad6e3ade5caff491d9e.json`
- `receipts/0xd7e2a7ae60a4438357b1222bb1d744d153a49dc07a8f2c0c995cd2145e0eee44.json`
- `receipts/0xd9d3b2fd9e54b8c5067e14c25f0336be1e3b59e4f754d53d53363f62aaf4c3a5.json`
- `receipts/0xe79f7771eecb1be4847ebcbfec864bf45b5b367a2ebbbc5dc115a56b6e09804e.json`
- `receipts/0xe9be566f82424857a0fff1406a452f7b99fbd0c1ee3cd0dfb021160e4227272b.json`
- `receipts/0xf3731d3bab01949c33be43cb687367a47680b55738966ed5b644319cd4356446.json`
- `report.md`
- `verify/VERIFY_EXPECTED.txt`
- `verify/_orvyren/__init__.py`
- `verify/_orvyren/audit_dossier.py`
- `verify/_orvyren/policy/__init__.py`
- `verify/_orvyren/policy/miniyaml.py`
- `verify/_orvyren/verify_engine.py`
- `verify/orvyren_verify.py`

## Notes

- **Three streams, one manifest**: `audit.jsonl` (execution), the reasoning
  stream (declared absent with a reason when the run had no LLM — never a
  simulated stream), `graph/graph_delta.jsonl` (knowledge; `graph_snapshot.json`
  and `provenance.json` carry the frozen state). The manifest fixes each
  stream's head; `audit.jsonl` then carries 3 `LINK` + 1 `SEAL` records that
  bind the chains together (B6 §1.4 — acyclic by construction).
- **Hash rules**: all digests are SHA-256; `record_hash = sha256(canonical_json(
  record minus record_hash))`, `prev_hash` = previous record of the same
  stream, genesis `0`×64. The dossier self-hash: zero the 64-hex self field,
  hash the file — reproducible with any SHA-256 tool.
- **Frozen verifier**: `verify/orvyren_verify.py` + `verify/_orvyren/` are a
  frozen copy of the repository module (`python -m orvyren.verify`); its file
  digests are listed in `HASHES.txt` (mutation M6 checks this).
- **Anchoring**: the published digest (option ii) is `BUNDLE_DIGEST.txt`
  (recomputed by verifier check A3). EAS anchoring on Base Sepolia is
  conditional (FREEZE_V2 F3) and was not executed for this packet.
- **Published zip digest**: recorded next to the zip (`<name>.zip.sha256`) —
  it cannot be inside the packet without a recursion.
