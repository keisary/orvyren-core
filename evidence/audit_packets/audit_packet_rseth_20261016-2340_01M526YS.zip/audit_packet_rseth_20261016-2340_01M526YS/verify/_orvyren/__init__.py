"""Frozen ORVYREN modules shipped with the audit packet."""
