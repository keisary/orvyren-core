#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Frozen ORVYREN third-party verifier (T10) — launcher.

Usage: python verify/orvyren_verify.py <packet_dir> [--mutate-test] [--rpc URL]
"""
import os
import sys

sys.dont_write_bytecode = True  # keep the packet byte-identical
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from _orvyren.verify_engine import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
