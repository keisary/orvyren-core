#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""ORVYREN-Core — policy service (lock 1, deterministic, off-LLM).

Role: receive a structured *intent* and return an ALLOW / DENY /
REQUIRE_APPROVAL verdict with the evaluated rules and stable reason codes.
The language model does not enter here: the policy is enforced by this code.

v1 set: **14 rules** (DOC2 §5.5.2 / FREEZE_V2 D1):
  P1  pinned chain              P8  permission (mandate) active
  P2  allowed asset             P9  intent freshness
  P3  allowed recipient         P10 idempotency (identifier + fingerprint)
  P4  scoped function           P11 pause / kill switch
  P5  per-transaction cap       P12 envelope alignment (SAFE MODE)
  P6  24 h rolling cumulative   P13 action scope
  P7  exposure / balance        P14 decision budget

Label history: R1–R8 (FREEZE_V1, D9) → P1–P14 (FREEZE_V2, D1).
The **denial codes are unchanged** (stable codes, DOC2 §5.5.1); a rule
that is not evaluated appears as `SKIPPED` with its reason — never silent.

Principles (DOC2 §5.5.1): fail-closed, deny-by-default, stable codes,
full evaluation of the applicable rules, verdict DENY > REQUIRE_APPROVAL > ALLOW.

Evaluation modes are **explicit** (never implicit):
  * `EVAL_MODE_PRODUCTION` (default): a `PolicyState` snapshot is REQUIRED.
    If the caller supplies none, the evaluation **refuses** with the stable
    code `STATE_REQUIRED` — the state rules are recorded as failures, never
    `SKIPPED` (fail-closed: forgetting the state must not silently produce a
    laxer verdict).
  * `EVAL_MODE_SIMULATION`: declared explicitly (tests, offline replays).
    Without a state, P7/P11/P12/P14 stay `SKIPPED` with a note naming the
    simulation mode — a declared, documented simulation, never a silent
    legacy path.

When a `PolicyState` is supplied, "required" fields are **fail-closed**: an
unreadable required field (None/invalid) is a denial, never a "we assume",
in both modes. The v1 parameters (intent TTL, function registry, decimals)
come from `policy_v1.yaml` via `load_policy()` (source of truth for the
parameters, DOC2 §5.5.3); without them, the rules concerned are `SKIPPED`
(legacy mode).

Running the tests: python -m unittest discover -s tests -v
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re

from dataclasses import dataclass, field
from decimal import Decimal
from datetime import datetime, timedelta, timezone
from typing import Iterable, Optional

from .miniyaml import MiniYamlError, load_file as _load_yaml_file

ALLOWED_CHAIN_ID = 84532                     # Base Sepolia
ALLOWED_ASSET = "0x036cbd53842c5426634e7929541eC2318f3dCF7e"   # test USDC (Circle, Base Sepolia)
MAX_PER_TX = 100.0                           # 100 test USDC
MAX_CUMULATIVE = 300.0                       # 300 test USDC
PERMISSION_TTL = timedelta(hours=24)
ACTIONS_AUTONOMES = {"transfer"}             # executable without a human, if every rule passes
ACTIONS_SOUS_APPROBATION = {"swap", "approve", "change_policy", "revoke"}  # never autonomous here
TRANSFER_SELECTOR = "0xa9059cbb"             # transfer(address,uint256)

CLOCK_SKEW_TOLERANCE = timedelta(seconds=60)
ENVELOPE_PASS = "PASS"
ENVELOPE_DRIFT = "DRIFT"
ENVELOPE_UNVERIFIED = "UNVERIFIED"

#: Denial codes (P12) that trigger SAFE MODE — distinct from envelope statuses.
SAFE_MODE_CODES = ("ENVELOPE_DRIFT", "ENVELOPE_UNVERIFIED")

#: Evaluation modes (`evaluate(mode=...)`). Production is the fail-closed
#: default; a simulation run must declare `EVAL_MODE_SIMULATION` explicitly —
#: simulation is never implicit (a caller that forgets the state is refused,
#: not silently simulated).
EVAL_MODE_PRODUCTION = "production"
EVAL_MODE_SIMULATION = "simulation"
EVAL_MODES = frozenset({EVAL_MODE_PRODUCTION, EVAL_MODE_SIMULATION})

#: Denial code: production evaluation without a `PolicyState` snapshot — the
#: state rules cannot be verified, so the intent is refused (fail-closed).
#: A state rule is never `SKIPPED` in production.
STATE_REQUIRED = "STATE_REQUIRED"

#: The 14 labels of the v1 set — used by the test bench as a registry.
RULES_V1 = (
    "P1-chain", "P2-asset", "P3-recipient", "P4-function", "P5-amount",
    "P6-cumulative", "P7-exposure", "P8-permission", "P9-freshness",
    "P10-idempotency", "P11-pause", "P12-envelope", "P13-action", "P14-budget",
)

#: v1 denial-code registry (stable — never renamed, never reused).
DENY_CODES_V1 = frozenset({
    "CHAIN_NOT_ALLOWED", "ASSET_NOT_ALLOWED", "RECIPIENT_NOT_ALLOWED",
    "TARGET_NOT_ALLOWED", "FUNCTION_NOT_ALLOWED", "OPERATION_NOT_ALLOWED",
    "AMOUNT_NOT_FINITE", "AMOUNT_INVALID", "AMOUNT_ABOVE_TX_CAP",
    "AMOUNT_ABOVE_PERIOD_CAP", "CUMULATIVE_INVALID",
    "BALANCE_UNREADABLE", "BALANCE_INSUFFICIENT", "FLOOR_BREACH", "EXPOSURE_ABOVE_CAP",
    "PERMISSION_MISSING", "PERMISSION_EXPIRED",
    "INTENT_STALE", "INTENT_NOT_YET_VALID",
    "INTENT_ALREADY_PROCESSED",
    "PAUSED", "AGENT_NOT_MEMBER", "STATE_REQUIRED",
    "ENVELOPE_DRIFT", "ENVELOPE_UNVERIFIED",
    "ACTION_UNKNOWN",
    "BUDGET_EXCEEDED", "BUDGET_UNREADABLE",
})

#: Reason codes including the approval verdict (not a denial).
REASON_CODES_V1 = DENY_CODES_V1 | {"ACTION_NEEDS_HUMAN_APPROVAL"}


@dataclass(frozen=True)
class Intent:
    """Structured operation request — unauthorized by nature."""
    intent_id: str
    action: str                     # transfer | swap | approve | change_policy | revoke
    chain_id: int
    asset: str                      # token address
    amount: float                   # in token units
    recipient: str                  # recipient or contract address
    created_at: datetime
    justification: str = ""


@dataclass
class PolicyConfig:
    allowed_chain_ids: frozenset = frozenset({ALLOWED_CHAIN_ID})
    allowed_assets: frozenset = frozenset({ALLOWED_ASSET})
    allowed_recipients: frozenset = frozenset()
    max_per_tx: float = MAX_PER_TX
    max_cumulative: float = MAX_CUMULATIVE
    permission_expires_at: datetime | None = None
    # --- v1 parameters (policy_v1.yaml) — None/empty = SKIPPED rule (legacy) ---
    intent_ttl: timedelta | None = None            # P9
    clock_skew: timedelta = CLOCK_SKEW_TOLERANCE   # P9
    asset_decimals: int | None = None              # P5 (decimals typo guard)
    allowed_operations: frozenset = frozenset()    # P4 (operation names)
    allowed_targets: frozenset = frozenset()       # P4 (normalized addresses)
    allowed_functions: frozenset = frozenset()     # P4 (normalized (target, selector))
    operation_calls: dict = field(default_factory=dict)  # P4 (action -> (target, selector))
    policy_version: str | None = None              # bundle version (verdict)
    policy_hash: str | None = None                 # bundle fingerprint (verdict)


@dataclass
class PolicyState:
    """External state supplied by the caller — required if `state` is passed to evaluate().

    Fail-closed: "required" means a None/invalid field **denies**.
    Fields marked optional (None = not configured) do not block.
    """
    paused: bool | None = None                 # P11 (required; None = unreadable)
    agent_member: bool | None = None           # P11 (required; None = unreadable)
    envelope_status: str | None = None         # P12 (required; DRIFT/UNVERIFIED/None = denial)
    available_balance: float | None = None     # P7 (required; None = unreadable)
    floor_balance: float | None = None         # P7 (optional: balance floor)
    exposure: float | None = None              # P7 (optional, with exposure_cap)
    exposure_cap: float | None = None          # P7 (optional)
    budget_spent: float | None = None          # P14 (optional, if budget_cap is absent too)
    budget_cap: float | None = None            # P14


@dataclass
class PolicyDecision:
    verdict: str                    # ALLOW | DENY | REQUIRE_APPROVAL
    reasons: list = field(default_factory=list)
    rules_evaluated: list = field(default_factory=list)
    policy_version: str | None = None
    policy_hash: str | None = None
    safe_mode: bool = False         # true if ENVELOPE_DRIFT / ENVELOPE_UNVERIFIED

    def as_dict(self):
        payload = {"verdict": self.verdict, "reasons": self.reasons,
                   "rules_evaluated": self.rules_evaluated}
        if self.policy_version is not None:
            payload["policy_version"] = self.policy_version
        if self.policy_hash is not None:
            payload["policy_hash"] = self.policy_hash
        return payload


@dataclass
class PolicyBundle:
    """Loaded `policy_v1.yaml`: parameters + identity (version + fingerprints)."""
    config: PolicyConfig
    data: dict
    version: str
    yaml_sha256: str
    code_sha256: str
    policy_hash: str


def _norm(addr) -> str:
    return (addr or "").strip().lower()


_ADDRESS_RE = re.compile(r"\A0x[0-9a-fA-F]{40}\Z")


def _strict_int(value, field: str) -> int:
    """Parse an integer policy field without bool/float coercion."""
    if isinstance(value, bool):
        raise MiniYamlError("policy_v1.yaml: '%s' must be an integer" % field)
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            raise MiniYamlError("policy_v1.yaml: '%s' must be an integer" % field)
        return int(value)
    if isinstance(value, str):
        text = value.strip()
        if not re.fullmatch(r"-?\d+", text):
            raise MiniYamlError("policy_v1.yaml: '%s' must be an integer" % field)
        return int(text)
    if isinstance(value, int):
        return value
    raise MiniYamlError("policy_v1.yaml: '%s' must be an integer" % field)


def _finite_number(value) -> bool:
    """True for a real, finite number (bool excluded).

    NaN and infinities must never reach the cap comparisons: in floating
    point, ``float('nan') > 100`` and ``float('nan') <= 100`` are both False,
    so a NaN amount would silently pass the caps (review finding F07).
    """
    return isinstance(value, (int, float)) and not isinstance(value, bool) \
        and math.isfinite(value)


def _aware(moment: datetime) -> datetime:
    """Utc-aware datetime; naive values are read as UTC (documented choice)."""
    return moment if moment.tzinfo is not None else moment.replace(tzinfo=timezone.utc)


def _dec(value) -> Decimal:
    """Exact decimal reading of an int/float (str round-trip = declared value).

    Money comparisons (per-tx cap, rolling cumulative, floor, exposure cap,
    decision budget) must be exact at the boundary: in float space
    ``0.1 + 0.2 > 0.3`` is True and ``0.3 - 0.1 < 0.2`` is True, so an intent
    sitting exactly on a cap would be denied (or a floor falsely breached).
    ``Decimal(str(value))`` restores each operand's declared decimal value.
    """
    return Decimal(str(value))


def _base_units(amount: float, decimals: int | None) -> Optional[int]:
    """Amount in the token's base units, or None if not exactly representable.

    Exact decimal arithmetic: the float form ``amount * 10 ** decimals`` with
    a 1e-6 absolute tolerance accepted off-grid amounts (e.g.
    100.00000000000001 at 6 decimals is 1.4e-14 token units off the grid yet
    passed the tolerance), letting two distinct amounts share one base-unit
    fingerprint in P10. An amount outside the token's grid is never
    representable — the caller denies it (P5).
    """
    if decimals is None or not _finite_number(amount):
        return None
    scaled = _dec(amount) * (Decimal(10) ** decimals)
    if scaled != scaled.to_integral_value():
        return None
    return int(scaled)


def intent_fingerprint(intent: Intent, decimals: int | None = None) -> str:
    """Fingerprint of the canonical intent content (P10) — independent of intent_id.

    Covers action, chain, asset, recipient and amount (in base units when
    the decimals are known): the same operational content re-submitted with
    a new identifier is detected.
    """
    payload = {
        "action": intent.action,
        "chain_id": intent.chain_id,
        "asset": _norm(intent.asset),
        "recipient": _norm(intent.recipient),
    }
    units = _base_units(intent.amount, decimals)
    payload["amount_base_units"] = units if units is not None else ("float:" + repr(intent.amount))
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _policy_code_sha256() -> str:
    """Fingerprint of the policy module code (semantic) — §5.5.3."""
    here = os.path.dirname(os.path.abspath(__file__))
    parts = []
    for name in ("__init__.py", "miniyaml.py"):
        with open(os.path.join(here, name), "rb") as handle:
            parts.append(handle.read())
    return hashlib.sha256(b"|".join(parts)).hexdigest()


def load_policy(path, recipients: Optional[dict] = None) -> PolicyBundle:
    """Load `policy_v1.yaml` — source of truth for the parameters (DOC2 §5.5.3).

    `recipients`: label → address table (demo recipient resolution; the file
    never contains a session address). File entries that already are `0x…`
    addresses are accepted as is.
    """
    data = _load_yaml_file(path)
    if not isinstance(data, dict):
        raise MiniYamlError("policy_v1.yaml must be a mapping")
    version = str(data.get("policy_version") or "").strip()
    if not version:
        raise MiniYamlError("policy_v1.yaml: 'policy_version' missing")

    chains = data.get("chain_ids") or ([data["chain_id"]] if data.get("chain_id") is not None else [])
    if not isinstance(chains, (list, tuple)) or not chains:
        raise MiniYamlError("policy_v1.yaml: 'chain_ids' must be a non-empty list")
    assets = data.get("assets") or ([data["asset"]] if data.get("asset") else [])
    if not isinstance(assets, (list, tuple)) or not assets:
        raise MiniYamlError("policy_v1.yaml: 'assets' must be a non-empty list")

    resolved, unresolved = set(), []
    for entry in (data.get("recipients") or []):
        candidate = None
        if isinstance(entry, str) and len(entry) == 42 and entry.startswith("0x"):
            candidate = entry
        elif isinstance(entry, str) and recipients:
            candidate = recipients.get(entry)
        if candidate:
            resolved.add(_norm(candidate))
        else:
            unresolved.append(entry)

    operations, targets, functions, calls = set(), set(), set(), {}
    for entry in (data.get("functions") or []):
        if not isinstance(entry, dict):
            raise MiniYamlError("policy_v1.yaml: 'functions' expects mappings")
        operation = str(entry.get("operation") or "").strip()
        target = _norm(str(entry.get("target") or ""))
        selector = str(entry.get("selector") or "").strip().lower()
        if not operation or not target or not selector:
            raise MiniYamlError("policy_v1.yaml: incomplete 'functions' entry (operation/target/selector)")
        operations.add(operation)
        targets.add(target)
        functions.add((target, selector))
        calls[operation] = (target, selector)

    try:
        max_per_tx = float(str(data.get("max_per_tx", MAX_PER_TX)))
        max_cumulative = float(str(data.get("max_cumulative_24h", MAX_CUMULATIVE)))
    except ValueError:
        raise MiniYamlError("policy_v1.yaml: 'max_per_tx'/'max_cumulative_24h' must be numbers")
    # A non-finite or non-positive cap would silently disable the comparison
    # (NaN never satisfies `> cap`): refuse it at load time, fail-closed.
    if not _finite_number(max_per_tx) or max_per_tx <= 0:
        raise MiniYamlError("policy_v1.yaml: 'max_per_tx' must be finite and > 0")
    if not _finite_number(max_cumulative) or max_cumulative <= 0:
        raise MiniYamlError("policy_v1.yaml: 'max_cumulative_24h' must be finite and > 0")
    try:
        allowed_chain_ids = frozenset(_strict_int(c, "chain_ids")
                                      for c in chains)
        asset_decimals = (_strict_int(data["asset_decimals"], "asset_decimals")
                          if data.get("asset_decimals") is not None else None)
        intent_ttl = (timedelta(minutes=_strict_int(
            data["ttl_intent_minutes"], "ttl_intent_minutes"))
            if data.get("ttl_intent_minutes") is not None else None)
        clock_skew = timedelta(seconds=_strict_int(
            data.get("clock_skew_seconds", int(CLOCK_SKEW_TOLERANCE.total_seconds())),
            "clock_skew_seconds"))
    except (TypeError, ValueError, OverflowError) as exc:
        raise MiniYamlError(
            "policy_v1.yaml: invalid chain/decimals/TTL/clock-skew value: %s" % exc) from exc
    if asset_decimals is not None and not 0 <= asset_decimals <= 36:
        raise MiniYamlError("policy_v1.yaml: 'asset_decimals' must be between 0 and 36")

    normalized_assets = []
    for asset in assets:
        if not isinstance(asset, str) or not _ADDRESS_RE.match(asset.strip()):
            raise MiniYamlError("policy_v1.yaml: 'assets' must contain 0x addresses")
        normalized_assets.append(_norm(asset))
    for entry in resolved:
        if not _ADDRESS_RE.match(entry):
            raise MiniYamlError("policy_v1.yaml: unresolved recipient is not an address")

    config = PolicyConfig(
        allowed_chain_ids=allowed_chain_ids,
        allowed_assets=frozenset(normalized_assets),
        allowed_recipients=frozenset(resolved),
        max_per_tx=max_per_tx,
        max_cumulative=max_cumulative,
        intent_ttl=intent_ttl,
        clock_skew=clock_skew,
        asset_decimals=asset_decimals,
        allowed_operations=frozenset(operations),
        allowed_targets=frozenset(targets),
        allowed_functions=frozenset(functions),
        operation_calls=dict(calls),
        policy_version=version,
    )

    canonical = json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    yaml_sha = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    code_sha = _policy_code_sha256()
    bundle_hash = hashlib.sha256((yaml_sha + ":" + code_sha).encode("utf-8")).hexdigest()
    config.policy_hash = bundle_hash
    bundle = PolicyBundle(config=config, data=data, version=version,
                          yaml_sha256=yaml_sha, code_sha256=code_sha, policy_hash=bundle_hash)
    if unresolved:
        bundle.data = dict(data, _unresolved_recipients=list(unresolved))
    return bundle


def evaluate(intent: Intent, config: PolicyConfig, now: datetime | None = None,
             seen_intent_ids: Iterable[str] = (), cumulative_spent: float = 0.0,
             state: Optional[PolicyState] = None,
             seen_intent_hashes: Iterable[str] = (),
             mode: str = EVAL_MODE_PRODUCTION) -> PolicyDecision:
    """Return the deterministic verdict for a given intent (14 applicable rules).

    `mode`: `EVAL_MODE_PRODUCTION` (default, fail-closed) or a simulation
    declared with `EVAL_MODE_SIMULATION` — never implicit; an unknown mode is
    a hard error. `state`: external-state snapshot (P7/P11/P12/P14). In
    production it is REQUIRED: without it the evaluation refuses with
    `STATE_REQUIRED` and the state rules are recorded as failures, never
    `SKIPPED`. A declared simulation without a state keeps documented
    `SKIPPED` entries (tests, offline replays). With a supplied state, the
    required fields must be readable — otherwise denial (fail-closed) in
    both modes.
    `seen_intent_hashes`: already-processed fingerprints (P10, dedup by content).
    """
    if not isinstance(mode, str) or mode not in EVAL_MODES:
        raise ValueError("unknown evaluation mode: %r (expected one of: %s)"
                         % (mode, ", ".join(sorted(EVAL_MODES))))
    now = _aware(now or datetime.now(timezone.utc))
    reasons, evaluated = [], []

    def fail(rule, code, note=""):
        entry = {"rule": rule, "result": "FAIL", "code": code}
        if note:
            entry["note"] = note
        evaluated.append(entry)
        reasons.append(code)

    def ok(rule, note=""):
        evaluated.append({"rule": rule, "result": "OK", "note": note})

    def skip(rule, note):
        evaluated.append({"rule": rule, "result": "SKIPPED", "note": note})

    def unverified(rule):
        """State rule with no snapshot: refused in production, skipped only in
        a declared simulation — never a silent legacy skip (fail-closed)."""
        if mode == EVAL_MODE_SIMULATION:
            skip(rule, "state not supplied — simulation mode (declared)")
        else:
            evaluated.append({"rule": rule, "result": "FAIL", "code": STATE_REQUIRED,
                              "note": "state not supplied — production evaluation "
                                      "cannot verify this rule (fail-closed refusal)"})
            if STATE_REQUIRED not in reasons:
                reasons.append(STATE_REQUIRED)

    def decision():
        return PolicyDecision("DENY" if reasons else "ALLOW", list(reasons), evaluated,
                              policy_version=config.policy_version,
                              policy_hash=config.policy_hash,
                              safe_mode=any(code in SAFE_MODE_CODES for code in reasons))

    # P13 (pre-policy) — action scope: unknown action -> hard denial
    if intent.action not in ACTIONS_AUTONOMES and intent.action not in ACTIONS_SOUS_APPROBATION:
        fail("P13-action", "ACTION_UNKNOWN")
        return PolicyDecision("DENY", list(reasons), evaluated,
                              policy_version=config.policy_version,
                              policy_hash=config.policy_hash)

    # P1 — allowed chain
    if intent.chain_id in config.allowed_chain_ids:
        ok("P1-chain", str(intent.chain_id))
    else:
        fail("P1-chain", "CHAIN_NOT_ALLOWED")
    if reasons:
        return PolicyDecision("DENY", list(reasons), evaluated,
                              policy_version=config.policy_version,
                              policy_hash=config.policy_hash)

    # P2 — allowed asset
    if _norm(intent.asset) not in {_norm(a) for a in config.allowed_assets}:
        fail("P2-asset", "ASSET_NOT_ALLOWED")
    else:
        ok("P2-asset")

    # P3 — allowed recipient
    if _norm(intent.recipient) not in {_norm(r) for r in config.allowed_recipients}:
        fail("P3-recipient", "RECIPIENT_NOT_ALLOWED")
    else:
        ok("P3-recipient")

    # P4 — scoped function (v1 registry: operations + (target, selector) pairs)
    if not (config.allowed_operations or config.allowed_functions or config.operation_calls):
        skip("P4-function", "function registry not configured (legacy)")
    else:
        mapping = config.operation_calls.get(intent.action)
        if mapping is None and intent.action in ACTIONS_SOUS_APPROBATION:
            # approval-only action: no on-chain call in v1 — P13 decides
            skip("P4-function", "approval-only action — no direct call in v1")
        elif mapping is None:
            fail("P4-function", "OPERATION_NOT_ALLOWED",
                 f"operation {intent.action} absent from the active registry")
        else:
            target, selector = mapping
            operation_ok = (not config.allowed_operations) or (intent.action in config.allowed_operations)
            target_matches_intent = (intent.action != "transfer"
                                     or _norm(intent.asset) == target)
            if not operation_ok:
                fail("P4-function", "OPERATION_NOT_ALLOWED")
            elif not target_matches_intent:
                fail("P4-function", "TARGET_NOT_ALLOWED",
                     f"transfer asset {intent.asset} != registered target {target}")
            elif target not in {_norm(t) for t in config.allowed_targets}:
                fail("P4-function", "TARGET_NOT_ALLOWED")
            elif (target, selector) not in {(t, s) for (t, s) in config.allowed_functions}:
                fail("P4-function", "FUNCTION_NOT_ALLOWED")
            else:
                ok("P4-function", f"{intent.action} -> ({target}, {selector})")

    # P5 — per-transaction cap (finite first; then decimals; then the cap)
    if not _finite_number(intent.amount):
        fail("P5-amount", "AMOUNT_NOT_FINITE")
    elif intent.amount <= 0:
        fail("P5-amount", "AMOUNT_INVALID")
    elif config.asset_decimals is not None and _base_units(intent.amount, config.asset_decimals) is None:
        fail("P5-amount", "AMOUNT_INVALID",
             f"amount not exactly representable in base units ({config.asset_decimals} decimals)")
    elif not _finite_number(config.max_per_tx) or config.max_per_tx <= 0:
        fail("P5-amount", "AMOUNT_ABOVE_TX_CAP",
             "max_per_tx unreadable (non-finite or non-positive) — fail closed")
    elif _dec(intent.amount) > _dec(config.max_per_tx):
        fail("P5-amount", "AMOUNT_ABOVE_TX_CAP")
    else:
        ok("P5-amount", f"{intent.amount} <= {config.max_per_tx}")

    # P6 — rolling cumulative (the strict lock of the period boundary)
    if not _finite_number(cumulative_spent) or cumulative_spent < 0:
        fail("P6-cumulative", "CUMULATIVE_INVALID")
    elif not _finite_number(intent.amount):
        evaluated.append({"rule": "P6-cumulative", "result": "SKIPPED",
                          "note": "amount not finite (see P5-amount)"})
    elif not _finite_number(config.max_cumulative) or config.max_cumulative <= 0:
        fail("P6-cumulative", "AMOUNT_ABOVE_PERIOD_CAP",
             "max_cumulative unreadable (non-finite or non-positive) — fail closed")
    elif _dec(cumulative_spent) + _dec(max(intent.amount, 0)) > _dec(config.max_cumulative):
        fail("P6-cumulative", "AMOUNT_ABOVE_PERIOD_CAP")
    else:
        ok("P6-cumulative", f"{cumulative_spent + max(intent.amount, 0)} <= {config.max_cumulative}")

    # P7 — exposure / balance (production requires a state snapshot)
    if state is None:
        unverified("P7-exposure")
    else:
        balance = state.available_balance
        if balance is None or not _finite_number(balance):
            fail("P7-exposure", "BALANCE_UNREADABLE")
        elif not _finite_number(intent.amount):
            skip("P7-exposure", "amount not finite (see P5-amount)")
        else:
            if _dec(intent.amount) > _dec(balance):
                fail("P7-exposure", "BALANCE_INSUFFICIENT")
            elif state.floor_balance is not None and not _finite_number(state.floor_balance):
                fail("P7-exposure", "BALANCE_UNREADABLE",
                     "floor_balance unreadable — fail closed")
            elif state.floor_balance is not None \
                    and (_dec(balance) - _dec(intent.amount)) < _dec(state.floor_balance):
                fail("P7-exposure", "FLOOR_BREACH")
            elif state.exposure_cap is not None:
                if state.exposure is None or not _finite_number(state.exposure) \
                        or not _finite_number(state.exposure_cap):
                    fail("P7-exposure", "BALANCE_UNREADABLE", "exposure unreadable")
                elif _dec(state.exposure) + _dec(intent.amount) > _dec(state.exposure_cap):
                    fail("P7-exposure", "EXPOSURE_ABOVE_CAP")
                else:
                    ok("P7-exposure", f"balance {balance}; exposure {state.exposure} + {intent.amount} <= {state.exposure_cap}")
            else:
                ok("P7-exposure", f"balance {balance} (floor/exposure not configured)")

    # P8 — permission (mandate) active
    if config.permission_expires_at is None:
        fail("P8-permission", "PERMISSION_MISSING")
    elif now >= _aware(config.permission_expires_at):
        fail("P8-permission", "PERMISSION_EXPIRED")
    else:
        ok("P8-permission", config.permission_expires_at.isoformat())

    # P9 — intent freshness
    if config.intent_ttl is None:
        skip("P9-freshness", "intent TTL not configured (legacy)")
    else:
        created = _aware(intent.created_at)
        age = now - created
        if age > config.intent_ttl:
            fail("P9-freshness", "INTENT_STALE", f"age {age} > TTL {config.intent_ttl}")
        elif -age > config.clock_skew:
            fail("P9-freshness", "INTENT_NOT_YET_VALID",
                 f"future timestamp by {-age} > tolerance {config.clock_skew}")
        else:
            ok("P9-freshness", f"age {age}")

    # P10 — idempotency (identifier OR content fingerprint)
    seen_ids = set(seen_intent_ids)
    seen_hashes = set(seen_intent_hashes)
    fingerprint = intent_fingerprint(intent, config.asset_decimals)
    if intent.intent_id in seen_ids:
        fail("P10-idempotency", "INTENT_ALREADY_PROCESSED", "identifier already seen")
    elif fingerprint in seen_hashes:
        fail("P10-idempotency", "INTENT_ALREADY_PROCESSED", "content fingerprint already seen")
    else:
        ok("P10-idempotency")

    # P11 — pause / kill switch (production requires a state snapshot)
    if state is None:
        unverified("P11-pause")
    else:
        if not isinstance(state.paused, bool):
            fail("P11-pause", "PAUSED", "pause state unreadable — fail closed")
        elif state.paused:
            fail("P11-pause", "PAUSED")
        elif not isinstance(state.agent_member, bool):
            fail("P11-pause", "AGENT_NOT_MEMBER", "role membership unreadable — fail closed")
        elif not state.agent_member:
            fail("P11-pause", "AGENT_NOT_MEMBER")
        else:
            ok("P11-pause")

    # P12 — envelope alignment (SAFE MODE)
    if state is None:
        unverified("P12-envelope")
    else:
        status = str(state.envelope_status or "").strip().upper()
        if status == ENVELOPE_DRIFT:
            fail("P12-envelope", "ENVELOPE_DRIFT")
        elif status != ENVELOPE_PASS:
            fail("P12-envelope", "ENVELOPE_UNVERIFIED",
                 f"envelope status {status or 'missing'} (SAFE MODE)")
        else:
            ok("P12-envelope")

    # P14 — decision budget (optional: None/None with a supplied state = declared
    # "not configured"; without any state it is unverifiable — refused in production)
    if state is None:
        unverified("P14-budget")
    elif state.budget_spent is None and state.budget_cap is None:
        skip("P14-budget", "decision budget not configured")
    else:
        spent, cap = state.budget_spent, state.budget_cap
        if spent is None or cap is None or not _finite_number(spent) or not _finite_number(cap) \
                or spent < 0 or cap <= 0:
            fail("P14-budget", "BUDGET_UNREADABLE")
        elif _dec(spent) >= _dec(cap):
            fail("P14-budget", "BUDGET_EXCEEDED", f"{spent} >= {cap}")
        else:
            ok("P14-budget", f"{spent} < {cap}")

    if reasons:
        return decision()

    # P13 (verdict) — known action outside the autonomous scope: always human review
    if intent.action in ACTIONS_SOUS_APPROBATION:
        evaluated.append({"rule": "P13-action", "result": "REQUIRE_APPROVAL",
                          "code": "ACTION_NEEDS_HUMAN_APPROVAL"})
        return PolicyDecision("REQUIRE_APPROVAL", ["ACTION_NEEDS_HUMAN_APPROVAL"], evaluated,
                              policy_version=config.policy_version,
                              policy_hash=config.policy_hash)

    evaluated.append({"rule": "P13-action", "result": "OK", "note": intent.action})
    return PolicyDecision("ALLOW", [], evaluated,
                          policy_version=config.policy_version,
                          policy_hash=config.policy_hash)


def default_config(reserve_recipient: str, ttl_hours: int = 24,
                   now: datetime | None = None) -> PolicyConfig:
    """Demo configuration: one chain, one asset, one recipient, one expiry."""
    now = _aware(now or datetime.now(timezone.utc))
    return PolicyConfig(
        allowed_recipients=frozenset({_norm(reserve_recipient)}),
        permission_expires_at=now + timedelta(hours=ttl_hours),
    )
