# ORVYREN — audit packet (rseth, run 01M5CCNN)

Testnet only (Base Sepolia, chainId 84532). No real funds were involved.
This packet is the auditable record of the ORVYREN demonstration run
(`run_id = 01M5CCNNTXNSC3YEVEPAJFBWWH`), assembled offline by `scripts/build_audit_packet.py`.
It carries **three journals** (execution / reasoning / knowledge), sealed by a
manifest and a LINK/SEAL junction (B6 §1.4), and a **frozen copy of the
third-party verifier** (T10).

## How to verify (offline, no network, no repository needed)

```bash
unzip audit_packet_rseth_20261020-1012_01M5CCNN.zip && cd audit_packet_rseth_20261020-1012_01M5CCNN
# 1) file integrity: every file against HASHES.txt (and the bundle digest)
sha256sum -c HASHES.txt        # the verifier redoes this check (A3) if coreutils is absent
# 2) full offline verification — expected: VERDICT: OFFLINE_PASS
python verify/orvyren_verify.py .
# 3) mutation self-test — expected: 6/6 mutations detected
python verify/orvyren_verify.py . --mutate-test
```

With network (optional, separate verdict): `python verify/orvyren_verify.py . --rpc https://sepolia.base.org`
re-reads every recorded transaction from the chain and re-matches it to its intent.

## What this audit packet proves

**What this audit packet proves.** (1) **Integrity** — no byte of the dossier or its journals has changed since sealing: any alteration breaks a hash chain or the dossier self-hash (INV-INTEGRITY). (2) **Recomputability** — every determinant computation (policy verdicts, dossier re-rendering, graph snapshot, intent↔receipt matching) is recomputed **offline** by a third party from the supplied pieces alone: same inputs, same versions, same outputs. (3) **Intent↔execution correspondence** — each recorded transaction is tied to an intent and a policy verdict and cross-checked against the public receipt (status, block, logs). (4) **Bounded mandate** — what the agent *could* do is a public, dated on-chain fact; the worst case is a finite, readable number. (5) **Point-in-time admissibility (INV-PIT)** — every fact carries event and retrieval timestamps; data inadmissible at decision time is excluded from the decision path. (6) **Refusals preserved** — policy denials, rejections, quarantines and abstentions are journaled and counted. (7) **Channel independence (INV-DEPENDENCE)** — two channels from the same archive never count as two confirmations. (8) **Accountability** — every step is attributed to a versioned component with its inputs and outputs.

## What this audit packet does not prove

**What this audit packet does not prove.** (1) The **truthfulness** of external sources — an oracle can be wrong while every hash is valid. (2) The **soundness** of hypotheses or the quality of decisions. (3) Any **financial performance** (returns, avoided loss, superiority over a baseline) — none is claimed. (4) **Completeness** — the packet covers signer actions and journaled steps; anything not journaled is not in it. (5) **LLM call text is not replayed** (inference nondeterminism); it is **covered by the journal** (prompts and responses archived and hashed, validators replayed). (6) Absence of **bugs** in upstream components. (7) **Legal or regulatory compliance** in any jurisdiction. (8) A **sealed digest** (if anchored) proves the integrity and dating of the anchored dossier, **not its truthfulness**.

## Inventory

- `BUNDLE_DIGEST.txt`
- `audit.jsonl`
- `baseline_report.json`
- `decision_usdc-2023-03.json`
- `dossier_usdc-2023-03.html`
- `dossier_usdc-2023-03.md`
- `fixtures/corpus_usdc_observations.csv`
- `fixtures/episode_rseth_2026-04.json`
- `fixtures/episode_steth_2022-06.json`
- `fixtures/episode_usdc_2023-03.json`
- `fixtures/graphs/rseth_2026-04.json`
- `fixtures/graphs/steth_2022-06.json`
- `fixtures/graphs/usdc_2023-03.json`
- `graph/graph_delta.jsonl`
- `graph/graph_snapshot.json`
- `graph/provenance.json`
- `manifest.json`
- `policy/intent_registry.json`
- `policy/policy.demo.json`
- `policy/policy.effective.json`
- `policy/signatures.jsonl`
- `policy_execution_demo.json`
- `quality_report.json`
- `receipts/0x23749217d1f641e9c737a9888931f478a95126e69e67be6cba989aa7f178d1af.json`
- `receipts/0x2f5c69d5cc5c7d570a24e5e495680ae86a0aa0389a7eb7f119b9be8d074ee10b.json`
- `receipts/0x3ac44fe8e571e01275e229dd9cd8a0f4fb6f976d344aaa79d9080b8dbf410aec.json`
- `receipts/0x408bb56d2ad3feadf31c0a0e128fb044573be77bf000619b51c5f97c99ad9775.json`
- `receipts/0x50140cad14bb41a27c77f57cbcbb30b3cae9ff3aa6184b4e9b69de6949d92622.json`
- `receipts/0x841cee455539a3e7cf196875ac55dc48f727af66e4e1b32e6b8019f30163e92a.json`
- `receipts/0x8a5a95c96851a4118d4643bcedf2fdeca1c44e787eedc42858aed46eebb41708.json`
- `receipts/0x977342d5b06964292e91d2eeda24c528a28e14dba06d3e338e516330fd1a5455.json`
- `receipts/0xc6c2bde904648042b58944016194a7893236082f0575459fe303d5bb99478faa.json`
- `receipts/0xf9d67562590df9fff5f907886dbe0ae767f5c56f49d2a49f86ca0edbbfca8670.json`
- `report.md`
- `verify/MUTATE_TEST_RESULTS.json`
- `verify/VERIFY_EXPECTED.txt`
- `verify/_orvyren/__init__.py`
- `verify/_orvyren/audit_dossier.py`
- `verify/_orvyren/evaluation_loss.py`
- `verify/_orvyren/policy/__init__.py`
- `verify/_orvyren/policy/miniyaml.py`
- `verify/_orvyren/verify_engine.py`
- `verify/orvyren_verify.py`

## Notes

- **Three streams, one manifest**: `audit.jsonl` (execution), the reasoning
  stream (declared absent with a reason when the run had no LLM — never a
  simulated stream), `graph/graph_delta.jsonl` (knowledge; `graph_snapshot.json`
  and `provenance.json` carry the frozen state). The manifest fixes each
  stream's head; `audit.jsonl` then carries 3 `LINK` + 1 `SEAL` records that
  bind the chains together (B6 §1.4 — acyclic by construction).
- **Hash rules**: all digests are SHA-256; `record_hash = sha256(canonical_json(
  record minus record_hash))`, `prev_hash` = previous record of the same
  stream, genesis `0`×64. The dossier self-hash: zero the 64-hex self field,
  hash the file — reproducible with any SHA-256 tool.
- **Frozen verifier**: `verify/orvyren_verify.py` + `verify/_orvyren/` are a
  frozen copy of the repository module (`python -m orvyren.verify`); its file
  digests are listed in `HASHES.txt` (mutation M6 checks this).
- **Anchoring**: the published digest (option ii) is `BUNDLE_DIGEST.txt`
  (recomputed by verifier check A3). EAS anchoring on Base Sepolia is
  conditional (FREEZE_V2 F3) and was not executed for this packet.
- **Published zip digest**: recorded next to the zip (`<name>.zip.sha256`) —
  it cannot be inside the packet without a recursion.
